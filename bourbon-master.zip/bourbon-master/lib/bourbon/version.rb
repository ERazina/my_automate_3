module Bourbon
  VERSION = "5.0.0.beta.7"
end
